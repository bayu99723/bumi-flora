<?php
include 'koneksi.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gudang PT Bumi Flora</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="wrapper">
        <!-- Navbar -->
        <div class="navbar" id="myNavbar">
            <a href="index.php" class="logo">Gudang PT Bumi Flora</a>
            <a href="index1.php">Input Barang</a>
            <a href="daftar-barang.php">Daftar Barang</a>
            <span class="menu-icon" onclick="toggleMenu()">&#9776;</span> <!-- Hamburger Icon -->
        </div>

        <!-- Tambah Barang Baru -->
        <h2 style="margin-top: 20px;">Tambah Barang Baru</h2>
        <form action="proses.php" method="POST">

            <label for="kodebarang">Kode Barang:</label>
            <input type="text" id="kodebarang" name="kode_barang" placeholder="BRG001" required readonly="">
            
            <label for="namabarang">Nama Barang:</label>
            <input type="text" id="namabarang" name="nama_barang" placeholder="Nama Barang" required>
            
            <label for="jumlah">Jumlah:</label>
            <input type="number" id="jumlah" name="jumlah" min="1" placeholder="0" required>

            <label for="unit">Unit:</label>
            <select id="unit" name="unit" required>
                <option value="" disabled selected>Pilih Opsi</option>
                <option value="buah">Buah</option>
                <option value="kg">Kg</option>
                <option value="liter">Liter</option>
            </select>
            
            <label for="kategori">Kategori:</label>
            <input type="text" id="kategori" name="kategori" placeholder="Kategori Barang" required>

            <label for="periode">Periode:</label>
            <input type="date" id="periode" name="periode" required>
            
            <label for="keterangan">Keterangan:</label>
            <input type="text" id="keterangan" name="keterangan" placeholder="Keterangan">
            
            <button type="submit">Tambah Barang</button>
        </form>

        <!-- Daftar Barang -->
        
    </div>
    <footer style="margin-top: 20px;">
        &copy; 2024 PT Bumi Flora. All rights reserved.
    </footer>

    <!-- JavaScript untuk Menu Icon -->
    <script>
        function toggleMenu() {
            var navbar = document.getElementById("myNavbar");
            navbar.classList.toggle("responsive");
        }
    </script>
</body>
</html>
