<?php
include 'koneksi.php';

// Ambil data barang tetap dari database
$sqlBarang = "SELECT * FROM barang";
$resultBarang = $conn->query($sqlBarang);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gudang PT Bumi Flora</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="wrapper">
        <!-- Navbar -->
        <div class="navbar" id="myNavbar">
            <a href="index.php" class="logo">Gudang PT Bumi Flora</a>
            <a href="index1.php">Input Barang</a>
            <a href="daftar-barang.php">Daftar Barang</a>
            <span class="menu-icon" onclick="toggleMenu()">&#9776;</span> <!-- Hamburger Icon -->
        </div>

        <!-- Tambah Barang Baru -->
        <h2 style="margin-top: 20px;">Tambah Barang Baru</h2>
        <form action="proses.php" method="POST">
            <label for="kodebarang">Kode Barang:</label>
            <input type="text" id="kodebarang" name="kode_barang" placeholder="BRG001" required>
            
            <label for="namaBarang">Nama Barang:</label>
            <input type="text" id="namaBarang" name="nama_barang" placeholder="Nama Barang" required>
            
            <label for="jumlah">Jumlah:</label>
            <input type="number" id="jumlah" name="jumlah" min="1" placeholder="0" required>
            
            <label for="kategori">Kategori:</label>
            <input type="text" id="kategori" name="kategori" placeholder="Kategori Barang" required>
            
            <label for="keterangan">Keterangan:</label>
            <input type="text" id="keterangan" name="keterangan" placeholder="Keterangan (opsional)">
            
            <button type="submit">Tambah Barang</button>
        </form>

        <!-- Daftar Barang -->
        <div class="container content" style="margin-top: 20px;">
            <h2>Daftar Barang Tetap</h2>
            <table>
                <thead>
                    <tr>
                        <th>Kode Barang</th>
                        <th>Nama Barang</th>
                        <th>Jumlah</th>
                        <th>Unit</th>
                        <th>Kategori</th>
                        <th>Keterangan</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $resultBarang->fetch_assoc()) { ?>
                        <tr>
                            <td><?= htmlspecialchars($row['kode_barang']) ?></td>
                            <td><?= htmlspecialchars($row['nama_barang']) ?></td>
                            <td><?= htmlspecialchars($row['jumlah']) ?></td>
                            <td><?= htmlspecialchars($row['unit']) ?></td>
                            <td><?= htmlspecialchars($row['kategori']) ?></td>
                            <td><?= htmlspecialchars($row['keterangan']) ?></td>
                            <td>
                                <a href="edit.php?id=<?= $row['id'] ?>">Edit</a> |
                                <a href="delete.php?id=<?= $row['id'] ?>" onclick="return confirm('Apakah Anda yakin ingin menghapus barang ini?')">Hapus</a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
    <footer style="margin-top: 20px;">
        &copy; 2024 PT Bumi Flora. All rights reserved.
    </footer>

    <!-- JavaScript untuk Menu Icon -->
    <script>
        function toggleMenu() {
            var navbar = document.getElementById("myNavbar");
            navbar.classList.toggle("responsive");
        }
    </script>
</body>
</html>
