<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to PT Bumi Flora</title>
    <link rel="stylesheet" href="css/welcome.css">
</head>
<body>
    <div class="welcome-wrapper">
        <div class="welcome-content">
            <h1 class="title">Welcome to PT Bumi Flora</h1>
            <p class="subtitle">Efisien. Dapat diandalkan. Aman.</p>
            <div class="buttons">
                <a href="index1.php" class="btn">Go to View Data</a>
            </div>
        </div>
    </div>
</body>
</html>
