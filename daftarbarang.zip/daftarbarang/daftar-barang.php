<?php
include 'koneksi.php';

// Ambil data barang berdasarkan periode tertentu (jika ada filter)
$periodeFilter = isset($_GET['periode']) ? $_GET['periode'] : null;
if ($periodeFilter) {
    $sqlNilai = "SELECT b.kode_barang, b.nama_barang, nb.jumlah, nb.unit, nb.keterangan
                 FROM barang b
                 LEFT JOIN nilai_barang nb ON b.id = nb.barang_id
                 WHERE nb.periode = '$periodeFilter'";
    $resultNilai = $conn->query($sqlNilai);
} else {
    $resultNilai = null;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Barang PT Bumi Flora</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="wrapper">
        <!-- Navbar -->
        <div class="navbar" id="myNavbar">
            <a href="#" class="logo">Gudang PT Bumi Flora</a>
            <a href="index.php">Input Barang</a>
            <a href="daftar-barang.php">Daftar Barang</a>
            <span class="menu-icon" onclick="toggleMenu()">&#9776;</span> <!-- Hamburger Icon -->
        </div>

        <div class="container content" style="margin-top: 20px;">
            <h2>Filter Data Barang Berdasarkan Periode Waktu</h2>
            <!-- Filter berdasarkan periode -->
            <form action="daftar-barang.php" method="GET">
                <label for="periode">Periode:</label>
                <input type="date" name="periode" required>
                <button type="submit">Filter</button>
            </form>
            <?php if ($resultNilai && $resultNilai->num_rows > 0) { ?>
                <table>
                    <thead>
                        <tr>
                            <th>Kode Barang</th>
                            <th>Nama Barang</th>
                            <th>Jumlah</th>
                            <th>Unit</th>
                            <th>Keterangan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $resultNilai->fetch_assoc()) { ?>
                            <tr>
                                <td><?= htmlspecialchars($row['kode_barang']) ?></td>
                                <td><?= htmlspecialchars($row['nama_barang']) ?></td>
                                <td><?= htmlspecialchars($row['jumlah']) ?></td>
                                <td><?= htmlspecialchars($row['unit']) ?></td>
                                <td><?= htmlspecialchars($row['keterangan']) ?></td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
                <!-- Tambahkan Tombol Cetak PDF -->
                <div class="button-container" style="margin-top: 20px;">
                    <form action="cetak-pdf.php" method="POST" target="_blank">
                        <input type="hidden" name="periode" value="<?= htmlspecialchars($periodeFilter) ?>">
                        <button type="submit" class="print-btn">Cetak PDF</button>
                    </form>
                </div>
            <?php } else if ($periodeFilter) { ?>
                <p>Data untuk periode ini tidak ditemukan.</p>
            <?php } ?>
        </div>
    </div>
    <footer style="margin-top: 20px;">
        &copy; 2024 PT Bumi Flora. All rights reserved.
    </footer>

    <!-- JavaScript untuk Menu Icon -->
    <script>
        function toggleMenu() {
            var navbar = document.getElementById("myNavbar");
            navbar.classList.toggle("responsive");
        }
    </script>
</body>
</html>
