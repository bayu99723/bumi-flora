<?php
include 'koneksi.php';

// Ambil data barang tetap dari database
$sqlBarang = "SELECT * FROM barang";
$resultBarang = $conn->query($sqlBarang);

// Ambil data barang berdasarkan periode tertentu (jika ada filter)
$periodeFilter = isset($_GET['periode']) ? $_GET['periode'] : null;
$kategoriFilter = isset($_GET['kategori']) ? $_GET['kategori'] : null;

// Membuat query SQL untuk mengambil data berdasarkan filter
if ($periodeFilter || $kategoriFilter) {
    $sqlNilai = "SELECT b.kode_barang, b.nama_barang, nb.jumlah, nb.unit, nb.keterangan
             FROM barang b
             LEFT JOIN nilai_barang nb ON b.id = nb.barang_id
             WHERE 1=1";

if ($periodeFilter) {
    $sqlNilai .= " AND nb.periode = '$periodeFilter'";
}
if ($kategoriFilter) {
    $sqlNilai .= " AND b.kategori LIKE '%$kategoriFilter%'";
}

    
    $resultNilai = $conn->query($sqlNilai);
} else {
    $resultNilai = null;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Barang PT Bumi Flora</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="wrapper">
        <!-- Navbar -->
        <div class="navbar" id="myNavbar">
            <a href="#" class="logo">Gudang PT Bumi Flora</a>
            <a href="index1.php">Input Barang</a>
            <a href="daftar-barang.php">Daftar Barang</a>
            <span class="menu-icon" onclick="toggleMenu()">&#9776;</span> <!-- Hamburger Icon -->
        </div>

        <div class="container content" style="margin-top: 20px;">
            <h2>Daftar Barang</h2>
            <table>
                <thead>
                    <tr>
                        <th>Kode Barang</th>
                        <th>Nama Barang</th>
                        <th>Jumlah</th>
                        <th>Unit</th>
                        <th>Kategori</th>
                        <th>Keterangan</th>
                        <th>Periode</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $resultBarang->fetch_assoc()) { ?>
                        <tr>
                            <td><?= htmlspecialchars($row['kode_barang']) ?></td>
                            <td><?= htmlspecialchars($row['nama_barang']) ?></td>
                            <td><?= htmlspecialchars($row['jumlah']) ?></td>
                            <td><?= htmlspecialchars($row['unit']) ?></td>
                            <td><?= htmlspecialchars($row['kategori']) ?></td>
                            <td><?= htmlspecialchars($row['keterangan']) ?></td>
                            <td><?= htmlspecialchars($row['periode']) ?></td>
                            <td>
                                <a href="edit.php?id=<?= $row['id'] ?>">Edit</a> |
                                <a href="delete.php?id=<?= $row['id'] ?>" onclick="return confirm('Apakah Anda yakin ingin menghapus barang ini?')">Hapus</a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>

        <div class="container content" style="margin-top: 20px;">
            <h2>Filter Data Barang Berdasarkan Periode dan Kategori</h2>
            <!-- Filter berdasarkan periode dan kategori -->
            <form id="filterForm" action="daftar-barang.php" method="GET">
                <label for="periode">Periode:</label>
                <input type="date" name="periode" id="periode" required>
                
                <label for="kategori">Kategori:</label>
                <input type="text" name="kategori" id="kategori" placeholder="Kategori">
                
                <button type="submit" id="filterButton">Filter</button>
            </form>

            <!-- Tabel Data Barang -->
            <div id="resultTable" style="display: <?php echo ($resultNilai && $resultNilai->num_rows > 0) ? 'block' : 'none'; ?>; margin-top: 20px;">
                <?php if ($resultNilai && $resultNilai->num_rows > 0) { ?>
                    <table>
                        <thead>
                            <tr>
                                <th>Kode Barang</th>
                                <th>Nama Barang</th>
                                <th>Jumlah</th>
                                <th>Unit</th>
                                <th>Keterangan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = $resultNilai->fetch_assoc()) { ?>
                                <tr>
                                    <td><?= htmlspecialchars($row['kode_barang']) ?></td>
                                    <td><?= htmlspecialchars($row['nama_barang']) ?></td>
                                    <td><?= htmlspecialchars($row['jumlah']) ?></td>
                                    <td><?= htmlspecialchars($row['unit']) ?></td>
                                    <td><?= htmlspecialchars($row['keterangan']) ?></td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                    <!-- Tombol Cetak PDF -->
                    <div class="button-container" style="margin-top: 20px;">
                        <form action="cetak-pdf.php" method="POST" target="_blank">
                            <input type="hidden" name="periode" value="<?= htmlspecialchars($periodeFilter) ?>">
                            <input type="hidden" name="kategori" value="<?= htmlspecialchars($kategoriFilter) ?>">
                            <button type="submit" class="print-btn">Cetak PDF</button>
                        </form>
                    </div>
                <?php } else if ($periodeFilter || $kategoriFilter) { ?>
                    <p>Data untuk filter yang dipilih tidak ditemukan.</p>
                <?php } ?>
            </div>
        </div>
    </div>
    <footer style="margin-top: 20px;">
        &copy; 2024 PT Bumi Flora. All rights reserved.
    </footer>

    <!-- JavaScript -->
    <script>
        // Cek apakah filter sudah dilakukan, jika iya tampilkan tabel
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.has('periode') || urlParams.has('kategori')) {
            document.getElementById('resultTable').style.display = 'block';
        }

        // Toggle Menu Icon
        function toggleMenu() {
            var navbar = document.getElementById("myNavbar");
            navbar.classList.toggle("responsive");
        }
    </script>
</body>
</html>
