<?php
session_start(); // Mulai session

include 'koneksi.php'; // Menghubungkan ke database

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil data dari form login
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Query untuk mencari username di database
    $sql = "SELECT * FROM users WHERE username = '$username'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Ambil data pengguna dari query result
        $row = $result->fetch_assoc();

        // Verifikasi password dengan password yang ada di database
        if (password_verify($password, $row['password'])) {
            // Password benar, simpan data session
            $_SESSION['username'] = $row['username'];
            $_SESSION['role'] = $row['role'];
            
            // Redirect berdasarkan role pengguna
            if ($row['role'] == 'admin') {
                header("Location: index1.php");
            } else {
                header("Location: index2.php");
            }
        } else {
            // Password salah
            echo "Password salah!";
        }
    } else {
        // Username tidak ditemukan
        echo "Username tidak ditemukan!";
    }
} else {
    // Jika bukan metode POST, arahkan ke login
    header("Location: index1.php");
}
?>
