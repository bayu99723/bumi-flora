<?php
include 'koneksi.php';

// Cek apakah parameter `id` ada
if (!isset($_GET['id'])) {
    echo "ID barang tidak ditemukan!";
    exit;
}

// Ambil data barang berdasarkan ID
$id = intval($_GET['id']);
$sqlBarang = "SELECT * FROM barang WHERE id = $id";
$result = $conn->query($sqlBarang);

// Cek apakah barang ditemukan
if ($result->num_rows === 0) {
    echo "Data barang tidak ditemukan!";
    exit;
}

$barang = $result->fetch_assoc();

// Proses update barang
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $kodeBarang = $_POST['kode_barang'];
    $namaBarang = $_POST['nama_barang'];
    $jumlah = $_POST['jumlah'];
    $unit = $_POST['unit'];
    $kategori = $_POST['kategori'];
    $keterangan = $_POST['keterangan'];

    $sqlUpdate = "UPDATE barang 
                  SET kode_barang = '$kodeBarang', nama_barang = '$namaBarang', jumlah = $jumlah, 
                      unit = '$unit', kategori = '$kategori', keterangan = '$keterangan'
                  WHERE id = $id";

    if ($conn->query($sqlUpdate) === TRUE) {
        echo "<script>alert('Data barang berhasil diperbarui!'); window.location = 'index1.php';</script>";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Barang</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="wrapper">
        <h2>Edit Barang</h2>
        <form action="" method="POST">
            <label for="kodebarang">Kode Barang:</label>
            <input type="text" id="kodebarang" name="kode_barang" value="<?= htmlspecialchars($barang['kode_barang']) ?>" required>
            
            <label for="namabarang">Nama Barang:</label>
            <input type="text" id="namabarang" name="nama_barang" value="<?= htmlspecialchars($barang['nama_barang']) ?>" required>
            
            <label for="jumlah">Jumlah:</label>
            <input type="number" id="jumlah" name="jumlah" value="<?= htmlspecialchars($barang['jumlah']) ?>" min="1" required>

            <label for="unit">Unit:</label>
            <select id="unit" name="unit" required>
                <option value="buah" <?= $barang['unit'] === 'buah' ? 'selected' : '' ?>>Buah</option>
                <option value="kg" <?= $barang['unit'] === 'kg' ? 'selected' : '' ?>>Kg</option>
                <option value="liter" <?= $barang['unit'] === 'liter' ? 'selected' : '' ?>>Liter</option>
            </select>
            
            <label for="kategori">Kategori:</label>
            <input type="text" id="kategori" name="kategori" value="<?= htmlspecialchars($barang['kategori']) ?>" required>
            
            <label for="keterangan">Keterangan:</label>
            <input type="text" id="keterangan" name="keterangan" value="<?= htmlspecialchars($barang['keterangan']) ?>">

            <button type="submit">Simpan Perubahan</button>
        </form>
    </div>
</body>
</html>
