<?php
include 'koneksi.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $sql = "SELECT * FROM barang WHERE id = $id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
    } else {
        echo "Data tidak ditemukan!";
        exit;
    }
} else {
    echo "ID tidak valid!";
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_barang = $_POST['nama_barang'];
    $jumlah = $_POST['jumlah'];
    $unit = $_POST['unit'];
    $kategori = $_POST['kategori'];
    $keterangan = $_POST['keterangan'];

    $updateSql = "UPDATE barang SET 
                    nama_barang = '$nama_barang', 
                    jumlah = $jumlah, 
                    unit = '$unit', 
                    kategori = '$kategori', 
                    keterangan = '$keterangan'
                  WHERE id = $id";
    if ($conn->query($updateSql)) {
        header("Location: index.php");
        exit;
    } else {
        echo "Gagal mengupdate data: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Barang</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h2>Edit Barang</h2>
    <form method="POST">
        <label>Nama Barang:</label>
        <input type="text" name="nama_barang" value="<?= htmlspecialchars($row['nama_barang']) ?>" required>
        
        <label>Jumlah:</label>
        <input type="number" name="jumlah" value="<?= htmlspecialchars($row['jumlah']) ?>" min="1" required>
        
        <label>Unit:</label>
        <input type="text" name="unit" value="<?= htmlspecialchars($row['unit']) ?>" required>
        
        <label>Kategori:</label>
        <input type="text" name="kategori" value="<?= htmlspecialchars($row['kategori']) ?>" required>
        
        <label>Keterangan:</label>
        <input type="text" name="keterangan" value="<?= htmlspecialchars($row['keterangan']) ?>">
        
        <button type="submit">Update Barang</button>
    </form>
</body>
</html>