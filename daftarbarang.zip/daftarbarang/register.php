<?php
include 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil data dari form
    $username = $_POST['username'];
    $password = $_POST['password'];
    $role = $_POST['role'];

    // Enkripsi password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Query untuk memasukkan data ke dalam database
    $sql = "INSERT INTO users (username, password, role) VALUES ('$username', '$hashed_password', '$role')";
    
    if ($conn->query($sql) === TRUE) {
        echo "Akun berhasil dibuat!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    header("Location: index.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - PT Bumi Flora</title>
    <link rel="stylesheet" href="css/login.css">
</head>
<body>
    <div class="login-wrapper">
        <div class="login-content">
            <h1 class="title">Register</h1>
            <form action="register.php" method="POST">
                <div class="container">
                    <input required type="text" name="username" class="input" id="username" style="color: #4caf50;">
                    <label for="username" class="label">Username</label>
                </div>
                <div class="container" style="margin-top: 30px;">
                    <input required type="password" name="password" class="input" id="password" style="color: #4caf50">
                    <label for="password" class="label">Password</label>
                </div>
                <div class="container" style="margin-top: 30px;">
                    <select required name="role" class="input" id="role" style="color: #4caf50;">
                        <option value="admin">Admin</option>
                        <option value="staff">Staff</option>
                    </select>
                    <label for="role" class="label">Role</label>
                </div>
                <button type="submit" class="btn" style="margin-top: 20px;">Register</button>
            </form>
            <p class="signup-link">Already have an account? <a href="login.php">Login</a></p>
        </div>
    </div>
</body>
</html>
