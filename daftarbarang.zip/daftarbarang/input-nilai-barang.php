<?php
include 'koneksi.php';

// Ambil data yang dikirimkan dari form
$periode = $_POST['periode'];
$jumlah = $_POST['jumlah'];
$unit = $_POST['unit'];
$keterangan = $_POST['keterangan'];

// Simpan nilai barang ke database
foreach ($jumlah as $barangId => $qty) {
    $barangUnit = $unit[$barangId];
    $barangKeterangan = $keterangan[$barangId];

    // Query untuk memasukkan data nilai barang
    $sql = "INSERT INTO nilai_barang (barang_id, periode, jumlah, unit, keterangan)
            VALUES ('$barangId', '$periode', '$qty', '$barangUnit', '$barangKeterangan')";

    if ($conn->query($sql) === TRUE) {
        echo "Data berhasil disimpan.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    header("Location: index.php"); // Redirect ke halaman utama
}
?>
