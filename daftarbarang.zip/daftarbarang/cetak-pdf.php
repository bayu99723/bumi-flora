<?php
require('fpdf.php');
include 'koneksi.php';

// Ambil filter periode dari POST
$periodeFilter = isset($_POST['periode']) ? $_POST['periode'] : null;

// Buat query untuk data barang
$sql = "SELECT b.kode_barang, b.nama_barang, nb.jumlah, nb.unit, nb.keterangan
        FROM barang b
        LEFT JOIN nilai_barang nb ON b.id = nb.barang_id";
if ($periodeFilter) {
    $sql .= " WHERE nb.periode = '$periodeFilter'";
}
$result = $conn->query($sql);

// Inisialisasi FPDF
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 14);

// Header
$pdf->Cell(0, 10, 'Daftar Barang PT Bumi Flora', 0, 1, 'C');
$pdf->SetFont('Arial', '', 12);
if ($periodeFilter) {
    $pdf->Cell(0, 10, 'Periode: ' . $periodeFilter, 0, 1, 'C');
}
$pdf->Ln(10);

// Tabel Header
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(40, 10, 'Kode Barang', 1);
$pdf->Cell(60, 10, 'Nama Barang', 1);
$pdf->Cell(20, 10, 'Jumlah', 1);
$pdf->Cell(20, 10, 'Unit', 1);
$pdf->Cell(50, 10, 'Keterangan', 1);
$pdf->Ln();

// Tabel Data
$pdf->SetFont('Arial', '', 10);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $pdf->Cell(40, 10, $row['kode_barang'], 1);
        $pdf->Cell(60, 10, $row['nama_barang'], 1);
        $pdf->Cell(20, 10, $row['jumlah'], 1);
        $pdf->Cell(20, 10, $row['unit'], 1);
        $pdf->Cell(50, 10, $row['keterangan'], 1);
        $pdf->Ln();
    }
} else {
    $pdf->Cell(0, 10, 'Tidak ada data ditemukan.', 1, 1, 'C');
}

// Output PDF
$pdf->Output();
?>
