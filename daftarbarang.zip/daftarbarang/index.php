<?php
include 'koneksi.php';

// Ambil data barang tetap
$sqlBarang = "SELECT * FROM barang";
$resultBarang = $conn->query($sqlBarang);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gudang PT Bumi Flora</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="wrapper">
        <!-- Navbar -->
        <div class="navbar" id="myNavbar">
            <a href="#" class="logo">Gudang PT Bumi Flora</a>
            <a href="index.php">Input Barang</a>
            <a href="daftar-barang.php">Daftar Barang</a>
            <span class="menu-icon" onclick="toggleMenu()">&#9776;</span> <!-- Hamburger Icon -->
        </div>

        <div class="container content" style="margin-top: 20px;">
            <h2>Daftar Barang Tetap</h2>
            <!-- Form untuk input nilai barang -->
            <form action="input-nilai-barang.php" method="POST">
                <label for="periode">Pilih Periode Waktu:</label>
                <input type="date" name="periode" required>
                <table>
                    <thead>
                        <tr>
                            <th>Kode Barang</th>
                            <th>Nama Barang</th>
                            <th>Jumlah</th>
                            <th>Keterangan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $resultBarang->fetch_assoc()) { ?>
                            <tr>
                                <td><?= htmlspecialchars($row['kode_barang']) ?></td>
                                <td><?= htmlspecialchars($row['nama_barang']) ?></td>
                                <td>
                                    <input type="number" name="jumlah[<?= $row['id'] ?>]" min="0" required>
                                    <!-- Dropdown untuk memilih unit -->
                                    <select name="unit[<?= $row['id'] ?>]" required>
                                        <option value="buah">Buah</option>
                                        <option value="kg">Kg</option>
                                        <option value="liter">Liter</option>
                                        <!-- Add other units if needed -->
                                    </select>
                                </td>
                                <td>
                                    <input type="text" name="keterangan[<?= $row['id'] ?>]">
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
                <button type="submit">Simpan Nilai</button>
            </form>

            <!-- Tombol Tambah Barang Baru -->
            <h2>Tambah Barang Baru</h2>
            <form action="proses.php" method="POST">
                <label for="namaBarang">Nama Barang:</label>
                <input type="text" id="namaBarang" name="namaBarang" required>
                <label for="kategori">Kategori:</label>
                <input type="text" id="kategori" name="kategori">
                <label for="lokasi">Lokasi:</label>
                <input type="text" id="lokasi" name="lokasi">
                <button type="submit">Tambah Barang</button>
            </form>
        </div>
    </div>
    <footer>
        &copy; 2024 PT Bumi Flora. All rights reserved.
    </footer>

    <!-- JavaScript untuk Menu Icon -->
    <script>
        function toggleMenu() {
            var navbar = document.getElementById("myNavbar");
            navbar.classList.toggle("responsive");
        }
    </script>
</body>
</html>
