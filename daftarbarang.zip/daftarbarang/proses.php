<?php
include 'koneksi.php';

// Fungsi untuk membuat kode barang otomatis
function generateKodeBarang($conn) {
    // Ambil kode barang dengan angka tertinggi
    $query = "SELECT kode_barang FROM barang ORDER BY CAST(SUBSTRING(kode_barang, 4) AS UNSIGNED) DESC LIMIT 1";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $lastKode = $row['kode_barang']; // Contoh: "BRG015"
        $number = (int) substr($lastKode, 3); // Ambil angka: 015
        $newNumber = $number + 1; // Increment angka
        return "BRG" . str_pad($newNumber, 3, "0", STR_PAD_LEFT); // Format ulang: BRG016
    } else {
        // Jika belum ada data, mulai dari BRG001
        return "BRG001";
    }
}


// Pastikan metode request adalah POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Buat kode barang otomatis
    $kode_barang = generateKodeBarang($conn);
    
    // Ambil data dari form
    $nama_barang = $_POST['nama_barang'];
    $jumlah = $_POST['jumlah'];
    $unit = $_POST['unit'];
    $kategori = $_POST['kategori'];
    $periode = $_POST['periode'];
    $keterangan = $_POST['keterangan'];

    // Query untuk menyimpan data ke database
    $sqlInsertBarang = "INSERT INTO barang (kode_barang, nama_barang, jumlah, unit, kategori, periode, keterangan) 
                        VALUES ('$kode_barang', '$nama_barang', '$jumlah', '$unit', '$kategori', '$periode',     '$keterangan')";

    // Eksekusi query dan cek hasilnya
    if ($conn->query($sqlInsertBarang) === TRUE) {
        header("Location: index1.php"); // Redirect ke halaman utama setelah sukses
    } else {
        echo "Error: " . $sqlInsertBarang . "<br>" . $conn->error;
    }
}
?>
