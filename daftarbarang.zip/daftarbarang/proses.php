<?php
include 'koneksi.php';

// Fungsi untuk membuat kode barang otomatis
function generateKodeBarang($conn) {
    // Ambil kode barang terakhir
    $query = "SELECT kode_barang FROM barang ORDER BY id DESC LIMIT 1";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $lastKode = $row['kode_barang']; // Contoh: "BRG015"
        $number = (int) substr($lastKode, 3); // Ambil angka: 015
        $newNumber = $number + 1; // Increment angka
        return "BRG" . str_pad($newNumber, 3, "0", STR_PAD_LEFT); // Format ulang: BRG016
    } else {
        // Jika belum ada data, mulai dari BRG001
        return "BRG001";
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $kodeBarang = generateKodeBarang($conn); // Buat kode otomatis
    $namaBarang = $_POST['namaBarang'];
    $kategori = $_POST['kategori'];
    $lokasi = $_POST['lokasi'];

    $sqlInsertBarang = "INSERT INTO barang (kode_barang, nama_barang, kategori, lokasi) 
                        VALUES ('$kodeBarang', '$namaBarang', '$kategori', '$lokasi')";

    if ($conn->query($sqlInsertBarang) === TRUE) {
        header("Location: index.php"); // Redirect ke halaman utama
    } else {
        echo "Error: " . $sqlInsertBarang . "<br>" . $conn->error;
    }
}
?>
