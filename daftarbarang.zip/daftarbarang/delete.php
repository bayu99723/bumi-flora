<?php
include 'koneksi.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $deleteSql = "DELETE FROM barang WHERE id = $id";

    if ($conn->query($deleteSql)) {
        header("Location: index.php");
        exit;
    } else {
        echo "Gagal menghapus data: " . $conn->error;
    }
} else {
    echo "ID tidak valid!";
}
?>