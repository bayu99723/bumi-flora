<?php
session_start();

// Cek apakah user sudah login dan role-nya adalah staff
if ($_SESSION['role'] != 'staff') {
    header("Location: login.php");
    exit();
}

include 'koneksi.php';

// Query untuk mengambil data yang bisa diubah oleh staff
$sql = "SELECT * FROM barang";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Staff Dashboard</title>
</head>
<body>
    <h1>Staff Dashboard</h1>
    <a href="logout.php">Logout</a>
    <table>
        <thead>
            <tr>
                <th>Kode Barang</th>
                <th>Nama Barang</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?= $row['kode_barang'] ?></td>
                    <td><?= $row['nama_barang'] ?></td>
                    <td>
                        <a href="edit-barang.php?id=<?= $row['id'] ?>">Edit</a>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</body>
</html>
