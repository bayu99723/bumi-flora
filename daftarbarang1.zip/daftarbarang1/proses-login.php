<?php
session_start();
include 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Query untuk mengambil data user
    $sql = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Jika username dan password cocok
        $row = $result->fetch_assoc();
        $_SESSION['username'] = $row['username'];
        $_SESSION['role'] = $row['role'];

        // Redirect berdasarkan role pengguna
        if ($row['role'] == 'admin') {
            header("Location: welcome.php");
        } else {
            header("Location: welcome1.php");
        }
    } else {
        // Username atau password salah
        echo "<script>alert('Username atau password salah!');</script>";
        header("Refresh:1; url=index.php");
    }
} else {
    // Jika bukan metode POST, arahkan ke login
    header("Location: index1.php");
}
?>
