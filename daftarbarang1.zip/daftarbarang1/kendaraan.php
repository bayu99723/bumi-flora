<?php
session_start();

// Cek apakah user sudah login dan role-nya adalah admin
if ($_SESSION['role'] != 'admin') {
    header("Location: index.php");
    exit();
}

include 'koneksi.php';
// Ambil semua kendaraan untuk kolom dinamis pada tabel
$sqlKendaraan = "SELECT DISTINCT Nama_Kendaraan FROM vehicle";
$resultKendaraan = $conn->query($sqlKendaraan);
$kendaraanList = [];
if ($resultKendaraan) {
    while ($row = $resultKendaraan->fetch_assoc()) {
        $kendaraanList[] = $row['Nama_Kendaraan'];
    }
}

$sqlNamaBarang = "SELECT DISTINCT nama_barang FROM barang";
$resultNamaBarang = $conn->query($sqlNamaBarang);
$namaBarangList = [];
if ($resultNamaBarang) {
    while ($row = $resultNamaBarang->fetch_assoc()) {
        $namaBarangList[] = $row['nama_barang'];
    }
}


// Query untuk mengambil data yang bisa diubah/dihapus
$sql = "SELECT * FROM barang";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gudang PT Bumi Flora</title>
    <link rel="stylesheet" href="css/style.css">

    <!-- Tambahkan CSS Select2 -->
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
</head>
<body>
    <div class="wrapper">
        <!-- Navbar -->
        <div class="navbar" id="myNavbar">
            <a href="#" class="logo">Gudang PT Bumi Flora</a>
            <a href="index1.php">Input Barang</a>
            <a href="daftar-barang.php">Daftar Barang</a>
            <span class="menu-icon" onclick="toggleMenu()">&#9776;</span> <!-- Hamburger Icon -->
        </div>

        <!-- Logout Button -->
        <form action="logout.php" method="POST" style="float: right; margin-top: 10px;">
            <button type="submit">Logout</button>
        </form>

        <!-- Kendaraan memakai barang -->
        <h2 style="margin-top: 42px;">Kendaraan mana yang memakai barang</h2>
        <form action="proses.php" method="POST">

            <label for="kendaraan">Kendaraan:</label>
            <select name="NamaVeh" id="kendaraan" style="color: black;">
                <option value="">Pilih Kendaraan</option>
                <?php foreach ($kendaraanList as $kendaraan) { ?>
                            <option><?= htmlspecialchars($kendaraan) ?></option>
                        <?php } ?>
            </select>

            <label for="namabarang">Nama Barang:</label>
            <select name="namabarang" id="namabarang" required>
                <option value="">Nama Barang</option>
                <?php foreach ($namaBarangList as $barang) { ?>
                    <option value="<?= htmlspecialchars($barang) ?>"><?= htmlspecialchars($barang) ?></option>
                <?php } ?>
            </select>
            
            <label for="jumlah">Jumlah yang dipakai:</label>
            <input type="number" id="jumlah" name="jumlah" min="1" placeholder="0" required>

            <label for="periode">Periode:</label>
            <input type="date" id="periode" name="periode" required>
            
            <button type="submit">Tambah Barang</button>
        </form>
    </div>

    <footer style="margin-top: 20px;">
        &copy; 2024 PT Bumi Flora. All rights reserved.
    </footer>

    <!-- Tambahkan JS Select2 -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    <!-- Inisialisasi Select2 -->
    <script>
        $(document).ready(function() {
            $('#unit').select2({
                placeholder: "Pilih Opsi",
                allowClear: true
            });
        });

        $(document).ready(function() {
            $('#kategori').select2({
                placeholder: "Pilih Kategori",
                allowClear: true
            });
        });

        // Fungsi Toggle Menu
        function toggleMenu() {
            var navbar = document.getElementById("myNavbar");
            navbar.classList.toggle("responsive");
        }
    </script>
</body>
</html>
