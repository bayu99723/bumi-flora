<?php
include 'koneksi.php';

// Cek apakah parameter `id` ada
if (!isset($_GET['id'])) {
    echo "ID barang tidak ditemukan!";
    exit;
}

// Ambil data barang berdasarkan ID
$id = intval($_GET['id']);
$sqlBarang = "SELECT * FROM barang WHERE id = $id";
$result = $conn->query($sqlBarang);

// Cek apakah barang ditemukan
if ($result->num_rows === 0) {
    echo "Data barang tidak ditemukan!";
    exit;
}

$barang = $result->fetch_assoc();

// Proses update barang
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $kodeBarang = $_POST['kode_barang'];
    $namaBarang = $_POST['nama_barang'];
    $jumlah = $_POST['jumlah'];
    $unit = $_POST['unit'];
    $kategori = $_POST['kategori'];
    $keterangan = $_POST['keterangan'];

    $sqlUpdate = "UPDATE barang 
                  SET kode_barang = '$kodeBarang', nama_barang = '$namaBarang', jumlah = $jumlah, 
                      unit = '$unit', kategori = '$kategori', keterangan = '$keterangan'
                  WHERE id = $id";

    if ($conn->query($sqlUpdate) === TRUE) {
        echo "<script>alert('Data barang berhasil diperbarui!'); window.location = 'daftar-barang.php';</script>";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Barang</title>
    <link rel="stylesheet" href="css/style.css">

    <!-- Tambahkan CSS Select2 -->
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
</head>
<body>
    <div class="wrapper">
        <h2>Edit Barang</h2>
        <form action="" method="POST">
            <label for="kodebarang">Kode Barang:</label>
            <input type="text" id="kodebarang" name="kode_barang" value="<?= htmlspecialchars($barang['kode_barang']) ?>" required readonly="">
            
            <label for="namabarang">Nama Barang:</label>
            <input type="text" id="namabarang" name="nama_barang" value="<?= htmlspecialchars($barang['nama_barang']) ?>" required>
            
            <label for="jumlah">Jumlah:</label>
            <input type="number" id="jumlah" name="jumlah" value="<?= htmlspecialchars($barang['jumlah']) ?>" min="1" required>

            <label for="unit">Unit:</label>
                <select id="unit" name="unit" class="select2" required>
                    <option value="buah" <?= $barang['unit'] === 'buah' ? 'selected' : '' ?>>Bh</option>
                    <option value="pcs" <?= $barang['unit'] === 'pcs' ? 'selected' : '' ?>>Pcs</option>
                    <option value="unit" <?= $barang['unit'] === 'unit' ? 'selected' : '' ?>>Unit</option>
                    <option value="psg" <?= $barang['unit'] === 'psg' ? 'selected' : '' ?>>Psg</option>
                    <option value="btg" <?= $barang['unit'] === 'btg' ? 'selected' : '' ?>>Btg</option>
                    <option value="kg" <?= $barang['unit'] === 'kg' ? 'selected' : '' ?>>Kg</option>
                    <option value="mtr" <?= $barang['unit'] === 'mtr' ? 'selected' : '' ?>>Mtr</option>
                    <option value="bks" <?= $barang['unit'] === 'bks' ? 'selected' : '' ?>>Bks</option>
                    <option value="roll" <?= $barang['unit'] === 'roll' ? 'selected' : '' ?>>Roll</option>
                    <option value="bal" <?= $barang['unit'] === 'bal' ? 'selected' : '' ?>>Bal</option>
                    <option value="ktk" <?= $barang['unit'] === 'ktk' ? 'selected' : '' ?>>Ktk</option>
                    <option value="pak" <?= $barang['unit'] === 'pak' ? 'selected' : '' ?>>Pak</option>
                    <option value="kpg" <?= $barang['unit'] === 'kpg' ? 'selected' : '' ?>>Kpg</option>
                    <option value="set" <?= $barang['unit'] === 'set' ? 'selected' : '' ?>>Set</option>
                    <option value="lbr" <?= $barang['unit'] === 'lbr' ? 'selected' : '' ?>>Lbr</option>
                    <option value="glg" <?= $barang['unit'] === 'glg' ? 'selected' : '' ?>>Glg</option>
                    <option value="sak" <?= $barang['unit'] === 'sak' ? 'selected' : '' ?>>Sak</option>
                    <option value="ikat" <?= $barang['unit'] === 'ikat' ? 'selected' : '' ?>>Ikat</option>
                    <option value="btl" <?= $barang['unit'] === 'btl' ? 'selected' : '' ?>>Btl</option>
                    <option value="jrg" <?= $barang['unit'] === 'jrg' ? 'selected' : '' ?>>Jrg</option>
                    <option value="liter" <?= $barang['unit'] === 'liter' ? 'selected' : '' ?>>Liter</option>
                    <option value="gram" <?= $barang['unit'] === 'gram' ? 'selected' : '' ?>>Gram</option>
                </select>
            
            <label for="kategori">Kategori:</label>
            <input type="text" id="kategori" name="kategori" value="<?= htmlspecialchars($barang['kategori']) ?>" required>
            
            <label for="keterangan">Keterangan:</label>
            <input type="text" id="keterangan" name="keterangan" value="<?= htmlspecialchars($barang['keterangan']) ?>">

            <button type="submit">Simpan Perubahan</button>
        </form>
    </div>

    <!-- Tambahkan JS Select2 -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    <!-- Inisialisasi Select2 -->
    <script>
        $(document).ready(function() {
            $('#unit').select2({
                placeholder: "Pilih Opsi",
                allowClear: true
            });
        });
    </script>
</body>
</html>
