<?php
session_start();
include 'koneksi.php';
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - PT Bumi Flora</title>
    <link rel="stylesheet" href="css/login.css">
</head>
<body>
    <div class="login-wrapper">
        <div class="login-content">
            <h1 class="title">Login</h1>
            <form action="proses-login.php" method="POST"> 
            <div class="container">
                <input required type="text" name="username" class="input" id="username" style="color: #4caf50">
                <label for="username" class="label">Username</label>
            </div>
            <div class="container" style="margin-top: 30px;">
                <input required type="password" name="password" class="input" id="password" style="color: #4caf50">
                <label for="password" class="label">Password</label>
            </div>
                
                <button type="submit" class="btn" style="margin-top: 20px;">Login</button>
            </form>
            <p class="signup-link">Don't have an account? <a href="register.php">Sign up</a></p>
        </div>
    </div>
</body>
</html>
