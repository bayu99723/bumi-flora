<?php
include 'koneksi.php';

// Ambil periode unik dari database
$sqlPeriode = "SELECT DISTINCT periode FROM barang";
$resultPeriode = $conn->query($sqlPeriode);

// Ambil kategori barang dari database
$sqlKategori = "SELECT DISTINCT kategori FROM barang";
$resultKategori = $conn->query($sqlKategori);

// Ambil data barang berdasarkan filter (jika ada)
$periodeFilter = isset($_GET['periode']) ? $_GET['periode'] : null;
$kategoriFilter = isset($_GET['kategori']) ? $_GET['kategori'] : null;

$sqlBarang = "SELECT id, kode_barang, nama_barang, stok_bulan_lalu, jumlah AS stok_bulan_ini, unit, kategori, periode FROM barang WHERE 1=1";
if ($periodeFilter) {
    $sqlBarang .= " AND periode = '$periodeFilter'";
}
if ($kategoriFilter) {
    $sqlBarang .= " AND kategori = '$kategoriFilter'";
}
$resultBarang = $conn->query($sqlBarang);

// Ambil semua kendaraan untuk kolom dinamis pada tabel
$sqlKendaraan = "SELECT DISTINCT Nama_Kendaraan FROM vehicle";
$resultKendaraan = $conn->query($sqlKendaraan);
$kendaraanList = [];
if ($resultKendaraan) {
    while ($row = $resultKendaraan->fetch_assoc()) {
        $kendaraanList[] = $row['Nama_Kendaraan'];
    }
}

// Ambil semua fraction untuk kolom dinamis pada tabel
$sqlFraction = "SELECT DISTINCT Nama FROM fraction";
$resultFraction = $conn->query($sqlFraction);
$fractionList = [];
if ($resultFraction) {
    while ($row = $resultFraction->fetch_assoc()) {
        $fractionList[] = $row['Nama'];
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Barang Gudang PT Bumi Flora</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="wrapper">
        <!-- Navbar -->
        <div class="navbar" id="myNavbar">
            <a href="#" class="logo">Gudang PT Bumi Flora</a>
            <a href="index1.php">Input Barang</a>
            <a href="daftar-barang.php">Daftar Barang</a>
            <span class="menu-icon" onclick="toggleMenu()">&#9776;</span>
        </div>

        <form action="logout.php" method="POST" style="float: right; margin-top: 10px;">
            <button type="submit">Logout</button>
        </form>

        <div class="container content" style="margin-top: 42px;">
            <h2>Filter Data Barang Berdasarkan Kategori dan Periode</h2>

            <!-- Filter berdasarkan kategori dan periode -->
            <form method="GET" action="daftar-barang.php" style="margin-bottom: 20px;">
                <label for="periode">Periode:</label>
                <select name="periode" id="periode">
                    <option value="">Pilih Periode</option>
                    <?php
                    while ($row = $resultPeriode->fetch_assoc()) {
                        echo "<option value='" . $row['periode'] . "' " . ($periodeFilter == $row['periode'] ? 'selected' : '') . ">" . $row['periode'] . "</option>";
                    }
                    ?>
                </select>

                <label for="kategori">Kategori:</label>
                <select name="kategori" id="kategori">
                    <option value="">Pilih Kategori</option>
                    <?php
                    while ($row = $resultKategori->fetch_assoc()) {
                        echo "<option value='" . $row['kategori'] . "' " . ($kategoriFilter == $row['kategori'] ? 'selected' : '') . ">" . $row['kategori'] . "</option>";
                    }
                    ?>
                </select>

                <button type="submit">Filter</button>
            </form>

            <!-- Tabel Daftar Barang -->
            <?php if ($resultBarang && $resultBarang->num_rows > 0) { ?>
                <table border="2">
                    <thead>
                        <tr>
                            <td style="text-align: center;" rowspan="2">Kategori</td>
                            <td style="text-align: center;" rowspan="2">Nama Barang</td>
                            <td style="text-align: center;" rowspan="2">Satuan</td>
                            <td style="text-align: center;" rowspan="2">Stock Bulan Lalu</td>
                            <td style="text-align: center;" rowspan="2">Stock Bulan Ini</td>
                            <td style="text-align: center;" colspan="<?= count($kendaraanList) ?>">Kendaraan</td>
                            <?php foreach ($fractionList as $fraction) { ?>
                                <td rowspan="2"><?= htmlspecialchars($fraction) ?></td>
                            <?php } ?>
                            <td style="text-align: center;" rowspan="2">Total Keluar</td>
                            <td style="text-align: center;" rowspan="2">Stock Akhir</td>
                            <td style="text-align: center;" rowspan="2">Aksi</td>
                        </tr>
                        <tr>
                            <?php foreach ($kendaraanList as $kendaraan) { ?>
                                <td><?= htmlspecialchars($kendaraan) ?></td>
                            <?php } ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $resultBarang->fetch_assoc()) { 
                            
                            $stok_bulan_lalu = !empty($row['stok_bulan_lalu']) ? $row['stok_bulan_lalu'] : 0;
                            $stok_bulan_ini = !empty($row['stok_bulan_ini']) ? $row['stok_bulan_ini'] : 0;
                            

                            // Hitung total keluar
                            $sqlTotalKeluar = "SELECT SUM(banyak) AS total_keluar FROM vehicle WHERE id_brg_dgnkan = '{$row['id']}'";
                            $resultTotalKeluar = $conn->query($sqlTotalKeluar);
                            $total_keluar = ($resultTotalKeluar && $resultTotalKeluar->num_rows > 0) ? $resultTotalKeluar->fetch_assoc()['total_keluar'] : 0;

                            // Hitung stok akhir
                            $stok_akhir = $stok_bulan_ini - $total_keluar;
                        ?>
                            <tr>
                                <td style="text-align: center;"><?= htmlspecialchars($row['kategori']) ?></td>
                                <td style="text-align: center;"><?= htmlspecialchars($row['nama_barang']) ?></td>
                                <td style="text-align: center;"><?= htmlspecialchars($row['unit']) ?></td>
                                <td style="text-align: center;"><?= htmlspecialchars($row['stok_bulan_lalu'] ?? 0) ?></td>

                                <td style="text-align: center;"><?= htmlspecialchars($row['stok_bulan_ini'] ?? 0) ?></td>
                                <?php foreach ($kendaraanList as $kendaraan) { 
                                    $sqlKendaraanBarang = "SELECT banyak FROM vehicle WHERE id_brg_dgnkan = '{$row['id']}' AND Nama_Kendaraan = '$kendaraan'";
                                    $resultKendaraanBarang = $conn->query($sqlKendaraanBarang);
                                    $banyak = ($resultKendaraanBarang && $resultKendaraanBarang->num_rows > 0) ? $resultKendaraanBarang->fetch_assoc()['banyak'] : 0;
                                ?>
                                    <td style="text-align: center;"><a href="kendaraan.php" class="invisible-button">tambah</a><?= htmlspecialchars($banyak) ?></td>
                                <?php } ?>
                                <?php foreach ($fractionList as $fraction) {
                                    $sqlFractionData = "SELECT banyak FROM fraction WHERE id_brg_dgnkan = '{$row['id']}' AND Nama = '$fraction'";
                                    $resultFractionData = $conn->query($sqlFractionData);
                                    $banyakFraction = ($resultFractionData && $resultFractionData->num_rows > 0) ? $resultFractionData->fetch_assoc()['banyak'] : 0;
                                ?>
                                    <td style="text-align: center;"><?= htmlspecialchars($banyakFraction) ?></td>
                                <?php } ?>
                                <td style="text-align: center;"><?= htmlspecialchars($total_keluar ?? 0) ?></td>
                                <td style="text-align: center;"><?= htmlspecialchars(max($stok_akhir, 0)) ?></td>
                                <td style="text-align: center;">
                                    <a href="edit.php?id=<?= $row['id'] ?>" title="Edit">
                                        <img src="img/pencil-fill.svg" alt="Edit" style="width:20px; height:20px;">
                                    </a>
                                    <a href="delete.php?id=<?= $row['id'] ?>" title="Delete" onclick="return confirm('Apakah Anda yakin ingin menghapus barang ini?')">
                                        <img src="img/trash-fill.svg" alt="Delete" style="width:20px; height:20px;">
                                    </a>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            <?php } else { ?>
                <p>Data barang tidak ditemukan.</p>
            <?php } ?>

            <!-- Tombol Cetak PDF hanya muncul jika sudah ada filter -->
            <div id="cetak-pdf-btn" style="display:none; margin-top: 20px;">
                <form action="cetak-pdf.php" method="GET">
                    <input type="hidden" name="periode" value="<?= htmlspecialchars($periodeFilter) ?>">
                    <input type="hidden" name="kategori" value="<?= htmlspecialchars($kategoriFilter) ?>">
                    <button type="submit">Cetak PDF</button>
                </form>
            </div>
        </div>
    </div>

    <footer>
        &copy; 2024 PT Bumi Flora. All rights reserved.
    </footer>

    <script>
        function toggleMenu() {
            var navbar = document.getElementById("myNavbar");
            navbar.classList.toggle("responsive");
        }

        window.onload = function() {
            const urlParams = new URLSearchParams(window.location.search);
            const periode = urlParams.get('periode');
            const kategori = urlParams.get('kategori');
            
            if (periode || kategori) {
                document.getElementById('cetak-pdf-btn').style.display = 'block';
            } else {
                document.getElementById('cetak-pdf-btn').style.display = 'none';
            }
        };
    </script>
</body>
</html>
