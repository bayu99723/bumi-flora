<?php
session_start(); // Mulai session

// Hapus session untuk logout
session_unset();
session_destroy();

// Arahkan ke halaman login
header("Location: index.php");
exit();
?>
