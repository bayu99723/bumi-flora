<?php
include 'koneksi.php';

// Cek apakah parameter `id` ada
if (!isset($_GET['id'])) {
    echo "ID barang tidak ditemukan!";
    exit;
}

// Hapus data barang berdasarkan ID
$id = intval($_GET['id']);
$sqlDelete = "DELETE FROM barang WHERE id = $id";

if ($conn->query($sqlDelete) === TRUE) {
    echo "<script>alert('Data barang berhasil dihapus!'); window.location = 'index1.php';</script>";
} else {
    echo "Error: " . $conn->error;
}
?>
