<?php
session_start();

// Cek apakah user sudah login dan role-nya adalah admin
if ($_SESSION['role'] != 'admin') {
    header("Location: index.php");
    exit();
}

include 'koneksi.php';

// Ambil semua kendaraan untuk kolom dinamis pada tabel
$sqlKendaraan = "SELECT DISTINCT Nama_Kendaraan FROM vehicle";
$resultKendaraan = $conn->query($sqlKendaraan);
$kendaraanList = [];
if ($resultKendaraan) {
    while ($row = $resultKendaraan->fetch_assoc()) {
        $kendaraanList[] = $row['Nama_Kendaraan'];
    }
}

// Query untuk mengambil data yang bisa diubah/dihapus
$sql = "SELECT * FROM barang";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gudang PT Bumi Flora</title>
    <link rel="stylesheet" href="css/style.css">

    <!-- Tambahkan CSS Select2 -->
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
</head>
<body>
    <div class="wrapper">
        <!-- Navbar -->
        <div class="navbar" id="myNavbar">
            <a href="#" class="logo">Gudang PT Bumi Flora</a>
            <a href="index1.php">Input Barang</a>
            <a href="daftar-barang.php">Daftar Barang</a>
            <span class="menu-icon" onclick="toggleMenu()">&#9776;</span> <!-- Hamburger Icon -->
        </div>

        <!-- Logout Button -->
        <form action="logout.php" method="POST" style="float: right; margin-top: 10px;">
            <button type="submit">Logout</button>
        </form>

        <!-- Tambah Barang Baru -->
        <h2 style="margin-top: 42px;">Tambah Barang Baru</h2>
        <form action="proses.php" method="POST">

            <label for="kodebarang">Kode Barang:</label>
            <input type="text" id="kodebarang" name="kode_barang" placeholder="BRG001" required readonly="">
            
            <label for="namabarang">Nama Barang:</label>
            <input type="text" id="namabarang" name="nama_barang" placeholder="Nama Barang" required>
            
            <label for="jumlah">Jumlah:</label>
            <input type="number" id="jumlah" name="jumlah" min="1" placeholder="0" required>

            <label for="unit">Unit:</label>
            <select id="unit" name="unit" required style="width: 100%;">
                <option value="" disabled selected>Pilih Opsi</option>
                <option value="buah">Bh</option>
                <option value="pcs">Pcs</option>
                <option value="unit">Unit</option>
                <option value="psg">Psg</option>
                <option value="btg">Btg</option>
                <option value="kg">Kg</option>
                <option value="mtr">Mtr</option>
                <option value="bks">Bks</option>
                <option value="roll">Roll</option>
                <option value="bal">Bal</option>
                <option value="ktk">Ktk</option>
                <option value="pak">Pak</option>
                <option value="kpg">Kpg</option>
                <option value="set">Set</option>
                <option value="lbr">Lbr</option>
                <option value="glg">Glg</option>
                <option value="sak">Sak</option>
                <option value="ikat">Ikat</option>
                <option value="btl">Btl</option>
                <option value="jrg">Jrg</option>
                <option value="liter">Liter</option>
                <option value="gram">Gram</option>
            </select>

            <!--
            <label for="kendaraan">Kendaraan</label>
            <input type="number" name="kendaraan">
            <select name="NamaVeh" id="NamaVeh" style="color: black;">
                <option value="">Pilih Kendaraan</option>
                <?php foreach ($kendaraanList as $kendaraan) { ?>
                    <option><?= htmlspecialchars($kendaraan) ?></option>
                <?php } ?>
            </select>
            -->
            
            <label for="kategori">Kategori:</label>
            <select id="kategori" name="kategori" required style="width: 100%;">
                <option value="" disabled selected>Pilih Kategori</option>
                <option value="Bengkel/Kendaraan">Bengkel/Kendaraan</option>
                <option value="BBM">BBM</option>
                <option value="Racun">Racun</option>
                <option value="Pupuk">Pupuk</option>
                <option value="Rambung Muda">Rambung Muda</option>
                <option value="Listrik">Listrik</option>
                <option value="Air">Air</option>
                <option value="Peralatan Bangunan">Peralatan Bangunan</option>
                <option value="Peralatan Pertanian">Peralatan Pertanian</option>
                <option value="Oli Pelumas">Oli Pelumas</option>
                <option value="Alat Lainnya">Alat Lainnya</option>
            </select>

            <label for="periode">Periode:</label>
            <input type="month" id="periode" name="periode" required>
            
            <label for="keterangan">Keterangan:</label>
            <input type="text" id="keterangan" name="keterangan" placeholder="Keterangan">
            
            <button type="submit">Tambah Barang</button>
        </form>
    </div>

    <footer style="margin-top: 20px;">
        &copy; 2024 PT Bumi Flora. All rights reserved.
    </footer>

    <!-- Tambahkan JS Select2 -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    <!-- Inisialisasi Select2 -->
    <script>
        $(document).ready(function() {
            $('#unit').select2({
                placeholder: "Pilih Opsi",
                allowClear: true
            });
        });

        $(document).ready(function() {
            $('#kategori').select2({
                placeholder: "Pilih Kategori",
                allowClear: true
            });
        });

        // Fungsi Toggle Menu
        function toggleMenu() {
            var navbar = document.getElementById("myNavbar");
            navbar.classList.toggle("responsive");
        }
    </script>
</body>
</html>
