-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 26 Nov 2024 pada 10.22
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gudang_belakang`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `barang`
--

CREATE TABLE `barang` (
  `id` int(11) NOT NULL,
  `kode_barang` varchar(10) NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `unit` enum('buah','kg','liter') NOT NULL,
  `kategori` varchar(50) DEFAULT NULL,
  `periode` date DEFAULT NULL,
  `keterangan` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `barang`
--

INSERT INTO `barang` (`id`, `kode_barang`, `nama_barang`, `jumlah`, `unit`, `kategori`, `periode`, `keterangan`) VALUES
(1, 'BRG456', 'pupuk', 40, 'kg', 'pupuk1', NULL, 'Barang rusak'),
(2, 'BRG002', 'Kunci Busi Shinso', 5, 'buah', 'Alat', NULL, 'Barang rusak'),
(3, 'BRG003', 'tanah', 20, 'buah', 'pupuk', '2024-11-27', 'Barang OK'),
(4, 'BRG457', 'semen', 20, 'buah', 'bangunan', '2024-11-26', 'Barang OK');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','staff') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`) VALUES
(1, 'admin', '$2y$10$FUkmPut1O7QSQgai86WwC.c7HQ6hR7kLrg5kSjo2r7I55Lp5a7dn6', 'admin'),
(3, 'staff', '$2y$10$vaHG9Tnf6rm.CVYXi6EP4ObDE41/Quwv2Ak/m2ODsczgRNp0GMN4C', 'staff'),
(4, 'admin1', '$2y$10$OieCz9R/dOGLA8KmCyEALO8Dtxd9.pBx6OhM7JUd31.sRNCRV6exW', 'admin'),
(5, 'staff1', '$2y$10$PH7SVjdClWA1Y18ianQSgeAaHZisyMW0ApYfObAz/2AcIGjTLjQmO', 'staff'),
(6, 'staff3', '$2y$10$FBxO3hsGMGV3qJUzgyqKiOeQCpxwE15.c4sHoCUY80DZ6aP/6ZpUW', 'staff');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `kode_barang` (`kode_barang`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `barang`
--
ALTER TABLE `barang`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
