<?php
include 'koneksi.php';

// Ambil periode unik dari database
$sqlPeriode = "SELECT DISTINCT periode FROM barang";
$resultPeriode = $conn->query($sqlPeriode);

// Ambil kategori barang dari database
$sqlKategori = "SELECT DISTINCT kategori FROM barang";
$resultKategori = $conn->query($sqlKategori);

// Ambil data barang berdasarkan filter (jika ada)
$periodeFilter = isset($_GET['periode']) ? $_GET['periode'] : null;
$kategoriFilter = isset($_GET['kategori']) ? $_GET['kategori'] : null;

$sqlBarang = "SELECT id, kode_barang, nama_barang, jumlah, unit, kategori, periode, keterangan FROM barang WHERE 1=1"; // Tambahkan `id` di SELECT
if ($periodeFilter) {
    $sqlBarang .= " AND periode = '$periodeFilter'";
}
if ($kategoriFilter) {
    $sqlBarang .= " AND kategori = '$kategoriFilter'";
}
$resultBarang = $conn->query($sqlBarang);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Barang PT Bumi Flora</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="wrapper">
        <!-- Navbar -->
        <div class="navbar" id="myNavbar">
            <a href="#" class="logo">Gudang PT Bumi Flora</a>
            <a href="index2.php">Input Barang</a>
            <a href="daftar-barang1.php">Daftar Barang</a>
            <span class="menu-icon" onclick="toggleMenu()">&#9776;</span> <!-- Hamburger Icon -->
        </div>

        <form action="logout.php" method="POST" style="float: right; margin-top: 10px;">
            <button type="submit">Logout</button>
        </form>

        <div class="container content" style="margin-top: 42px;">
            <h2>Filter Data Barang Berdasarkan Kategori dan Periode</h2>

            <!-- Filter berdasarkan kategori dan periode -->
            <form method="GET" action="daftar-barang1.php" style="margin-bottom: 20px;">
                <label for="periode">Periode:</label>
                <select name="periode" id="periode">
                    <option value="">Pilih Periode</option>
                    <?php
                    while ($row = $resultPeriode->fetch_assoc()) {
                        echo "<option value='" . $row['periode'] . "' " . ($periodeFilter == $row['periode'] ? 'selected' : '') . ">" . $row['periode'] . "</option>";
                    }
                    ?>
                </select>

                <label for="kategori">Kategori:</label>
                <select name="kategori" id="kategori">
                    <option value="">Pilih Kategori</option>
                    <?php
                    while ($row = $resultKategori->fetch_assoc()) {
                        echo "<option value='" . $row['kategori'] . "' " . ($kategoriFilter == $row['kategori'] ? 'selected' : '') . ">" . $row['kategori'] . "</option>";
                    }
                    ?>
                </select>

                <button type="submit">Filter</button>
            </form>

            <!-- Tabel Daftar Barang -->
            <?php if ($resultBarang && $resultBarang->num_rows > 0) { ?>
                <table>
                    <thead>
                        <tr>
                            <th>Kode Barang</th>
                            <th>Nama Barang</th>
                            <th>Jumlah</th>
                            <th>Unit</th>
                            <th>Kategori</th>
                            <th>Periode</th>
                            <th>Keterangan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $resultBarang->fetch_assoc()) { ?>
                            <tr>
                                <td><?= htmlspecialchars($row['kode_barang']) ?></td>
                                <td><?= htmlspecialchars($row['nama_barang']) ?></td>
                                <td><?= htmlspecialchars($row['jumlah']) ?></td>
                                <td><?= htmlspecialchars($row['unit']) ?></td>
                                <td><?= htmlspecialchars($row['kategori']) ?></td>
                                <td><?= htmlspecialchars($row['periode']) ?></td>
                                <td><?= htmlspecialchars($row['keterangan']) ?></td>
                                <td>
                                    <!-- Tombol Edit dan Hapus -->
                                    <a href="edit.php?id=<?= $row['id'] ?>" title="Edit">
                                        <img src="img/pencil-fill.svg" alt="Edit" style="width:20px; height:20px;">
                                    </a>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            <?php } else { ?>
                <p>Data barang tidak ditemukan.</p>
            <?php } ?>

            <!-- Tombol Cetak PDF hanya muncul jika sudah ada filter -->
            <div id="cetak-pdf-btn" style="display:none; margin-top: 20px;">
                <form action="cetak-pdf.php" method="GET">
                    <!-- Kirim parameter filter melalui URL -->
                    <input type="hidden" name="periode" value="<?= htmlspecialchars($periodeFilter) ?>">
                    <input type="hidden" name="kategori" value="<?= htmlspecialchars($kategoriFilter) ?>">
                    <button type="submit">Cetak PDF</button>
                </form>
            </div>
        </div>
    </div>

    <footer style="margin-top: 20px;">
        &copy; 2024 PT Bumi Flora. All rights reserved.
    </footer>

    <!-- JavaScript untuk Menu Icon -->
    <script>
        function toggleMenu() {
            var navbar = document.getElementById("myNavbar");
            navbar.classList.toggle("responsive");
        }

        window.onload = function() {
            // Ambil parameter periode dan kategori dari URL
            const urlParams = new URLSearchParams(window.location.search);
            const periode = urlParams.get('periode');
            const kategori = urlParams.get('kategori');
            
            // Jika periode atau kategori ada, tampilkan tombol Cetak PDF
            if (periode || kategori) {
                document.getElementById('cetak-pdf-btn').style.display = 'block';
            } else {
                document.getElementById('cetak-pdf-btn').style.display = 'none';
            }
        };
    </script>
</body>
</html>
